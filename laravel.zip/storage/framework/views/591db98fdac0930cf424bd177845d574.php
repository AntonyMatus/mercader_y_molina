

<?php $__env->startSection('title', 'FAQ'); ?>

<?php $__env->startSection('content'); ?>
  <section class="offer sp_1502 margin">
    <div class="offer_wrapper">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-12 mb-5">
            <div class="section_header2">
              <h2 class="section_heading2 aos-init aos-animate text-dark text-center" data-aos="fade-up">
                Descubre cómo los hábitos saludables <br> transforman tu calidad de vida
              </h2>
            </div>
          </div>
          <div class="row column-reverse">
            <div class="col-lg-6">
              <div class="offer_container">
                <!-- section header area here  -->
                
                <!-- lists  -->
                <div class="offer_lists">
                  <div class="offer_list aos-init aos-animate" data-aos="fade-up">
                    <div class="offer_content">
                      <div class="thumb">
                        <img src="assets/images/icon/features4.png" alt="">
                      </div>
                      <div class="content">
                        <h6 class="section_heading2 monserrat">Atención Personalizada</h6>
                        <p class="inter">Creemos que cada persona es única y requiere un enfoque personalizado para lograr sus objetivos de salud y nutrición.</p>
                      </div>
                    </div>
                  </div>
                  <div class="offer_list aos-init aos-animate" data-aos="fade-up">
                    <div class="offer_content">
                      <div class="thumb">
                        <img src="assets/images/icon/features4.png" alt="">
                      </div>
                      <div class="content">
                        <h6 class="section_heading2">Nutrición basada en la evidencia</h6>
                        <p>Utilizamos un enfoque basado en la ciencia para desarrollar tratamientos nutricionales personalizados para nuestros pacientes, asegurando que cada recomendación esté respaldada por la investigación científica.</p>
                      </div>
                    </div>
                  </div>
                  <div class="offer_list aos-init aos-animate" data-aos="fade-up">
                    <div class="offer_content">
                      <div class="thumb">
                        <img src="assets/images/icon/features4.png" alt="">
                      </div>
                      <div class="content">
                        <h6 class="section_heading2">Asesoría constante</h6>
                        <p>En Numana, nos aseguramos de que nuestros pacientes siempre se sientan acompañados y apoyados en su camino hacia una vida más saludable.</p>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- button -->
                <div class="button aos-init aos-animate" data-aos="fade-up">
                  <button onclick="redirectRoute('<?php echo e(route('services')); ?>')" type="button" class="mainButton buttonH1">¡Ver servicios! <span><i class="fa-solid fa-arrow-right-long"></i></span></button>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="offer_banner">
                  <div class="img-position">
                    <img data-aos="slide-left" data-aos-delay="100" src=" <?php echo e(asset('assets/images/faq/filete_de_pollo.jpeg')); ?> " alt="" height="auto" class="aos-init aos-animate">
                  </div>
                  <div class="patterns">
                    <img class="img-faq" src=" <?php echo e(asset('assets/images/faq/faq_img.png')); ?> "  alt="faq img">
                  </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </section>
  <section class="margin">
    <div class="c_accordion sp_120">
      <div class="c_accor_wrapper">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="c_accor_container">
                <!-- section header area here  -->
                <div class="section_header">
                  <h2 class="section_heading aos-init aos-animate font-weight-600 mw-100 text-left" data-aos="fade-up">Preguntas Frecuentes</h2>
                </div>
                <!-- accordion  -->
                <div class="c_accor_content">
                  <div class="accordion" id="accordionExample">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="accordion-item aos-init aos-animate" data-aos="fade-up">
                        <h2 id="headingOne">
                          <button 
                            class="accordion-button" 
                            type="button" 
                            data-bs-toggle="collapse" 
                            data-bs-target="#collapse-<?php echo e($loop->index); ?>" 
                            aria-expanded="true" 
                            aria-controls="collapse-<?php echo e($loop->index); ?>"
                          >
                            <?php echo e($faq->question); ?>

                          </button>
                        </h2>
                        <div 
                          id="collapse-<?php echo e($loop->index); ?>" 
                          class="accordion-collapse collapse <?php echo e(($loop->index === 0) ? 'show' : ''); ?>" 
                          aria-labelledby="headingOne" 
                          data-bs-parent="#accordionExample"
                        >
                          <div class="accordion-body">
                            <p><?php echo $faq->answer; ?></p>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div> <!-- accordion ends -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  
  </section>
  
  <section class="grow margin">
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 p-0">
            <div class="container p-0 m-0">
              <div class="row">
                <div class="col-12 m-0 p-0">
                  <div class="grow_container">
                    <div class="grow_content">
                      <div class="grow_items">
                        <div class="grow_item aos-init aos-animate" data-aos="fade-up">
                          <div class="content">
                            <img src="assets/images/single_images/img_testimonios.png" alt="" width="200px">
                            <h4>¡Agenda tu cita ahora!</h4>
                            <button type="button" onclick="redirectRoute('<?php echo e(route("services")); ?>')" class="whiteButton2 buttonH1 mt-5 monserrat fs-20px">¡Agendar ahora!</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mercader_and_molina\resources\views/pages/faq.blade.php ENDPATH**/ ?>