<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="aHero blogHero">
        <div class="aHero_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="aHero_container">
                            <div class="section_header">
                                <h2 class="section_heading font-weight-700 urbanist" data-aos="fade-up">Blog</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php
        $q_category = Request::get('category');
        $q_search = Request::get('search');
    ?>

    <section class="b_filter">
        <div class="b_filter_wrapper">
	        <div class="container">
	            <div class="row">
		            <div class="col-12">
		                <div class="b_filter_container">
			                <div class="b_filter_items">
			                    <div class="b_filter_item" data-aos="fade-up">
				                    <div class="b_filter_content">
				                        <h4 class="heading urbanist">Buscar por palabra</h4>
				                        <div class="keyword">
					                        <form action="<?php echo e(route('blog')); ?>" method="GET">
					                            <div class="from_content">
						                            <div class="from_input">
						                                <input type="text" name="search" placeholder="Palabra clave">
						                            </div>
						                            <div class="from_button">
						                                <button type="submit" class="mainButton buttonH1"><i class="fa-solid fa-magnifying-glass"></i> Buscar</button>
						                            </div>
					                            </div>
					                        </form>
				                        </div>
				                    </div>
			                    </div>
			                    <div class="b_filter_item" data-aos="fade-up">
				                    <div class="b_filter_content">
				                        <h4 class="heading urbanist">Buscar por categoría</h4>
				                        <ul class="category">
					                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <button 
                                                        type="button" 
                                                        class="mainButton buttonH1" onclick="redirectRoute('<?php echo e(route('blog')); ?>?category=<?php echo e($category->id); ?>')">
                                                        <?php echo e($category->name); ?>

                                                    </button>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                        </ul>
				                    </div>
			                    </div>
			                </div>
		                </div>
		            </div>
	            </div>
	        </div>
        </div>
    </section>

    <?php if(empty($q_category) && empty($q_search)): ?>
        <section class="blog margin">
            <div class="blog_wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="blog_container">
                                <h4 class="blog_heading urbanist" data-aos="fade-up">Últimas entradas</h4>
                                <div class="blog_items">
                                    <?php $__currentLoopData = $latest_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <div class="blog_item" data-aos="fade-up" onclick="redirectRoute('<?php echo e(route('single_blog')); ?>?post_id=<?php echo e($post->id); ?>')">
                                            <div class="blog_content">
                                                <div class="thumb">
                                                    <img lazy="loading" src="<?php echo e(asset('storage/blogs/' . $post->cover_image)); ?>" alt="Imagen de portada">
                                                </div>
                                                <div class="content">
                                                    <div class="button">
                                                        <button type="button" class="secondaryButton buttonH1">
                                                            <?php echo e($post->category->name); ?>

                                                        </button>
                                                        <h5 class="title">
                                                            <a class="urbanist" href="<?php echo e(route('single_blog')); ?>?post_id=<?php echo e($post->id); ?>">
                                                                <?php echo e($post->title); ?>

                                                            </a>
                                                        </h5>
                                                        <hr>
                                                        <ul class="date">
                                                            <li><span><?php echo e($post->publish_date); ?></span></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section class="blog margin">
        <div class="blog_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="blog_container">
                            <h4 class="blog_heading urbanist" data-aos="fade-up"> 
                                <?php if(!empty($q_category)): ?>
                                    Categoría: <?php echo e($category_filter->name); ?>

                                <?php endif; ?>
                                <?php if(!empty($q_search)): ?>
                                    Palabra clave: <?php echo e($q_search); ?>

                                <?php endif; ?>
                                <?php if(empty($q_category) && empty($q_search)): ?>
                                    Entradas Destacadas
                                <?php endif; ?>
                            </h4>
                            <div class="blog_items">
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="blog_item" data-aos="fade-up" onclick="redirectRoute('<?php echo e(route('single_blog')); ?>?post_id=<?php echo e($post->id); ?>')">
                                        <div class="blog_content">
                                            <div class="thumb">
                                                <img lazy="loading" src="<?php echo e(asset('storage/blogs/' . $post->cover_image)); ?>" alt="Imagen de portada">
                                            </div>
                                            <div class="content">
                                                <div class="button">
                                                    <button type="button" class="secondaryButton buttonH1">
                                                        <?php echo e($post->category->name); ?>

                                                    </button>
                                                    <h5 class="title">
                                                        <a href="<?php echo e(route('single_blog')); ?>?post_id=<?php echo e($post->id); ?>">
                                                            <?php echo e($post->title); ?>

                                                        </a>
                                                    </h5>
                                                    <hr>
                                                    <ul class="date">
                                                        <li><span><?php echo e($post->publish_date); ?></span></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php echo e($posts->links('components.pagination')); ?>

                </div>
            </div>
        </div>
    </section>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mercader_and_molina\resources\views/pages/blog.blade.php ENDPATH**/ ?>