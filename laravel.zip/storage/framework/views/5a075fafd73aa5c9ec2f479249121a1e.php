

<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('styles'); ?>
    <link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="inde_hero">
        <div class="inde_hero_wrapper">
            <div class="container">
            <div class="row">
                <div class="col-12">
                <div class="inde_hero_container">
                    <div class="thumb secction_thumb aos-init aos-animate" data-aos="fade-up">
                    <img loading="lazy" src="https://via.placeholder.com/1089x589" alt="page_services">
                    </div>
                    <div class="inde_hero_content aos-init aos-animate" data-aos="fade-up">
                    <div class="single_content">
                        <div class="thumb">
                        <img src="https://via.placeholder.com/87x88 " alt="icon_services">
                        </div>
                        <h4 class="name">Mercader y Molina</h4>
                        <p class="info">CEO - Mercader</p>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
    </section>

    <section class="inde_about sp_bottom120 pb-0">
        <div class="inde_about_wrapper">
            <div class="container p-0">
                <div class="row">
                    <div class="col-12 p-0">
                        <div class="inde_about_container">
                            <div class="section_header">
                                <h2 class="section_heading aos-init aos-animate font-weight-600" data-aos="fade-up">Servicios</h2>
                                <p data-aos="fade-up" class="section_heading3 aos-init aos-animate text-dark" style="max-width: 700px; text-align: center;">Las consultas se realizarán en línea, serán 100% <br> personalizadas según tus necesidades.</p>
                            </div>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="content mb-5rem border_line">
                                    <h2 class="background2 mb-4 p-0" data-aos="fade-up">
                                        <span class="decoration aos-init aos-animate text-inherit margin " data-aos="slide-left" data-aos-delay="100">
                                            <?php echo e($service->name); ?>

                                        </span>
                                    </h2>
                                    <p class="margin" data-aos="fade-up">
                                        <?php echo e($service->description); ?>

                                    </p>
                                    <h5 class="mb-2 font-weight-400 margin">Duración: <?php echo e($service->time); ?> minutos</h5>
                                    <div class="row price mb-5rem margin">
                                        <div class="col-md-12 content-flex p-0 ">
                                            <div class="precio-flex">
                                                <h2 class="fs-35px ">
                                                    <span class="">$ </span><?php echo e(number_format($service->eur_price, 2)); ?> <span class="fz-10px">USD</span>
                                                </h2>
                                            </div>
                                            <button onclick="selectService('<?php echo e($service->link_calendly); ?>')" type="button" class="mainButton buttonH1">
                                                ¡Agendar una consulta!
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="cta cta3">
        <div class="cta_wrapper2 margin">
          <div class="container">
            <div class="row">
              <div class="col-12">
                <div class="cta_container">
                  <div class="section_header2">
                    <h2 class="section_heading2 aos-init aos-animate" data-aos="fade-up">¡Estamos para ayudarte! </h2>
                    <p data-aos="fade-up" class="aos-init aos-animate">Sí tienes alguna duda sobre los servicios, ¡contáctame!</p>
                  </div>
                  <div class="cta_form aos-init aos-animate d-grid2" data-aos="fade-up">
                        <button type="submit" onclick="window.location='https://wa.me/message/'" class="contact-button buttonH1" id="btn-subscribe">Contacto vía Whatsapp</button>
                   </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- patterns  -->
        
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://assets.calendly.com/assets/external/widget.js" type="text/javascript" async></script>
    <script type="text/javascript">
        const selectService = (url) => { 
            Calendly.initPopupWidget({url});
            return false; 
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mercader_and_molina\resources\views/pages/services.blade.php ENDPATH**/ ?>