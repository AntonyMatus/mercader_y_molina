<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>
    <section class="aHero blog_details_hero">
        <div class="aHero_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="aHero_container">
                            <div class="section_header">
                                <h2 class="section_heading urbanist" data-aos="fade-up"><?php echo e($post->title); ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="blog_details pb-60px">
        <div class="bd_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="bd_container">
                            <div class="bd_post_info">
                                <div class="profile" data-aos="fade-up">
                                    <div class="thumb">
                                        <img loading="lazy" src="<?php echo e(asset('storage/' . $post->author->cover_image)); ?>"  alt="Foto del autor">
                                    </div>
                                    <div class="name">
                                        <h4 class="urbanist"><?php echo e($post->author->name); ?></h4>
                                    </div>
                                </div>
                                <div class="publish_date" data-aos="fade-up" data-aos-delay="100">
                                    <div class="thumb"><i class="fa-solid fa-calendar"></i></div>
                                    <div class="date">
                                        <p><?php echo e($post->publish_date); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="bd_content">
                                <div class="thumb text-center" data-aos="fade-up">
                                    <img loading="lazy" src="<?php echo e(asset('storage/blogs/' . $post->cover_image)); ?>"  alt="Imagen de portada">
                                </div>
                                <div class="content">
                                    <?php echo $post->body; ?>

                                </div>
                                
                                <div class="bd_info mt-5">
                                    <p data-aos="fade-up">
                                        Publicado el <span class="date"> <?php echo e($post->publish_date); ?></span> por <a class="name"><?php echo e($post->author->name); ?></a>
                                    </p>
                                    <div class="share" data-aos="fade-up" data-aos-delay="100">
                                        <p>Compartir este artículo</p>
                                        <ul>
                                            <li>
                                                <a 
                                                    type="button" 
                                                    onclick="copyLink('<?php echo e(route("single_blog")); ?>?post_id=<?php echo e($post->id); ?>')"
                                                >
                                                    <i class="fa-solid fa-link"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    href="https://www.facebook.com/sharer.php?u=<?php echo e(route('single_blog')); ?>?post_id=<?php echo e($post->id); ?>"
                                                    target="_blank" 
                                                    rel="noopener noreferrer"
                                                >
                                                    <i class="fa-brands fa-facebook-f"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    href="https://twitter.com/intent/tweet?url=<?php echo e(route('single_blog')); ?>?post_id=<?php echo e($post->id); ?>" 
                                                    target="_blank" 
                                                    rel="noopener noreferrer"
                                                >
                                                    <i class="fa-brands fa-twitter"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="blog margin">
        <div class="blog_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="blog_container">
                        <h4 class="blog_heading" data-aos="fade-up" data-aos-delay="100">Entradas similares</h4>
                            <div class="blog_items">
                                <?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="blog_item" data-aos="fade-up" onclick="redirectRoute('<?php echo e(route('single_blog')); ?>?post_id=<?php echo e($item->id); ?>')">
                                        <div class="blog_content">
                                            <div class="thumb">
                                                <img loading="lazy" src="<?php echo e(asset('storage/blogs/' . $item->cover_image)); ?>" alt="Imagen de portada">
                                            </div>
                                            <div class="content">
                                                <div class="button">
                                                    <button type="button" class="secondaryButton buttonH1">
                                                        <?php echo e($item->category->name); ?>

                                                    </button>
                                                    <h5 class="title">
                                                        <a href="<?php echo e(route('single_blog')); ?>?post_id=<?php echo e($item->id); ?>">
                                                            <?php echo e($item->title); ?>

                                                        </a>
                                                    </h5>
                                                    <hr>
                                                    <ul class="date">
                                                        <li><span><?php echo e($post->publish_date); ?></span></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="grow">
        <div class="container-fluid p-0">
          <div class="row">
            <div class="col-12 p-0">
                <div class="container ">
                  <div class="row">
                    <div class="col-12 m-0 p-0">
                      <div class="grow_container">
                        <div class="grow_content">
                          <div class="grow_items">
                            <div class="grow_item aos-init aos-animate" data-aos="fade-up">
                              <div class="content">
                                <img src="<?php echo e(asset('assets/images/banner/mercader_molina.png')); ?>" alt="" width="200px">
                                <h4>¡Agenda tu cita ahora!</h4>
                                <button type="button" onclick="redirectRoute('<?php echo e(route("home")); ?>')" class="clientButton buttonH1 mt-5 monserrat fs-20px">¡Agendar ahora!</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script type="text/javascript">

        const copyLink = (value) => {
            const input = document.createElement('input');
            input.value = value;
            document.body.appendChild(input);
            input.select();
            document.execCommand('copy');
            document.body.removeChild(input);
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mercader_and_molina\resources\views/pages/single_blog.blade.php ENDPATH**/ ?>