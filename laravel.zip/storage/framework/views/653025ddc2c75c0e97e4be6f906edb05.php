
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>Mercader & Molina - Dashboard</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="<?php echo e(asset('assets/images/icon/favicon.png')); ?>">
 
        <link href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('admin/assets/css/metismenu.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('admin/assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
        <?php echo $__env->yieldContent('style'); ?>
    </head>

    <body>

        <div <?php if(auth()->guard()->check()): ?> id="wrapper" <?php endif; ?> <?php if(auth()->guard()->guest()): ?> class="wrapper-page" <?php endif; ?>>
            <!-- Top Bar Start -->
    
            <?php if(auth()->guard()->check()): ?>
                <div class="topbar">
    
                    <!-- LOGO -->
                    <div class="topbar-left">
                        <a class="logo">
                            <span>
                                <img 
                                    loading="lazy"
                                    src="<?php echo e(asset('assets/images/logo/logo_white.png')); ?>" 
                                    class="img-fluid" 
                                    width="120"
                                />
                            </span>
                            <i>
                                <img
                                    loading="lazy"
                                    src="<?php echo e(asset('assets/images/icon/logo-white.png')); ?>"
                                    class="img-fluid" 
                                    width="60"
                                />
                            </i>
                        </a>
                    </div>
    
                    <nav class="navbar-custom">
    
                        <ul class="navbar-right d-flex list-inline float-right mb-0">
                            
                        </ul>
    
                        <ul class="list-inline menu-left mb-0">
                            <li class="float-left">
                                <button class="button-menu-mobile open-left waves-effect">
                                    <i class="mdi mdi-menu"></i>
                                </button>
                            </li>
                        </ul>
    
                    </nav>
    
                </div>
            <?php endif; ?>
    
            <?php if(auth()->guard()->check()): ?>
    
                
    
                <div class="left side-menu">
                    <div class="slimscroll-menu" id="remove-scroll">
    
                        <!--- Sidemenu -->
                        <div id="sidebar-menu">
                            <!-- Left Menu Start -->
                            <ul class="metismenu" id="side-menu">
                                <li class="menu-title">Main</li>
                                <li>
                                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-clipboard-text"></i><span> Blogs <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(route('Blogs.index')); ?>">Listado</a></li>
                                        <li><a href="<?php echo e(route('Blogs.create')); ?>">Crear Blog</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-view-list"></i><span> Categorias <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(route('categories.index')); ?>">Listado</a></li>
                                        <li><a href=" <?php echo e(route('categories.create')); ?> ">Crear categoria</a></li>
    
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-clipboard-outline"></i><span> Autores <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(route('Authors.index')); ?>">Listado</a></li>
                                        <li><a href=" <?php echo e(route('Authors.create')); ?> ">Crear Autor</a></li>
    
                                    </ul>
                                </li>
                                <?php if(auth()->user()->is_admin  === 0): ?>
                                <li class="d-none">
                                    <a href="javascript:void(0);" class="waves-effect"><i class="far fa-user-circle"></i><span> Usuarios <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(route('Users.index')); ?>">Listado</a></li>
                                        <li><a href=" <?php echo e(route('Users.create')); ?> ">Crear Usuario</a></li>
    
                                    </ul>
                                </li>
                                <?php elseif(auth()->user()->is_admin == 1): ?>
                                <li>
                                    <a href="javascript:void(0);" class="waves-effect"><i class="far fa-user-circle"></i><span> Usuarios <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(route('Users.index')); ?>">Listado</a></li>
                                        <li><a href=" <?php echo e(route('Users.create')); ?> ">Crear Usuario</a></li>
    
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <li>
                                    <a 
                                        class="waves-effect"
                                        onclick="event.preventDefault();
                                        document.getElementById('logout-form-sidenav').submit();"
                                    >
                                        <i class="fas fa-sign-out-alt"></i><span> Cerrar Session </span>
                                    </a>
                                    <form id="logout-form-sidenav" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    
                                </li>
                            </ul>
    
                        </div>
                        <!-- Sidebar -->
                        <div class="clearfix"></div>
    
                    </div>
                    <!-- Sidebar -left -->
    
                </div>
            <?php endif; ?>
    
            <?php if(auth()->guard()->check()): ?>
                <div class="content-page ">
                    <!-- Start content -->
                    <div class="content">
                        <div class="container-fluid" id="app">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
    
                    <footer class="footer">
                        © <span id="year"></span> Mercader & Molina - Desarrollado por <a href="https://www.buho-solutions.com/" target="_blank" rel="noopener noreferrer">Buho Solutions</a>.
                    </footer>
    
                </div>
            <?php endif; ?>
    
            <?php if(auth()->guard()->guest()): ?>
                <?php echo $__env->yieldContent('content'); ?>
            <?php endif; ?>
        </div>
        
        <!-- jQuery  -->
        <script src="<?php echo e(asset('admin/assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/metisMenu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/waves.min.js')); ?>"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('admin/assets/js/app.js')); ?>"></script>
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html><?php /**PATH C:\laragon\www\mercader_and_molina\resources\views/layouts/admin.blade.php ENDPATH**/ ?>