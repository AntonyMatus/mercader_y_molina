<?php $__env->startSection('title', 'Contacto'); ?>

<?php $__env->startSection('content'); ?>
    <section class="contact_hero sp_120 margin">
        <div class="ch_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="ch_container">
                            <div class="ch_content">
                                <div class="section_header">
                                    <h2 class="section_heading urbanist font-weight-700" data-aos="fade-up">¡Contáctanos!</h2>
                                    <p class="desc" data-aos="fade-up"></p>
                                </div>
                            </div>
                            <div class="ch_items">
                                <div class="ch_item" data-aos="fade-up" data-aos-delay="100">
                                    <div class="thumb">
                                        <span><i class="fa-solid fa-envelope"></i></span>
                                    </div>
                                    <div class="content">
                                        <h6 class="urbanist">correo Electrónico</h6>
                                        <p>contacto@numana.mx</p>
                                    </div>
                                </div>
                                <div class="ch_item" data-aos="fade-up" data-aos-delay="200">
                                    <div class="thumb">
                                        <span><i class="fa-solid fa-phone"></i></span>
                                    </div>
                                    <div class="content">
                                        <h6 class="urbanist">WhatsApp</h6>
                                        <p>+52 558 558 3103</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="contact margin">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="col-12 p-0">
                    <div class="contact_wrapper sp_120">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="contact_container">
                                        <div class="contact_info">
                                            <div class="section_header">
                                                <h2 class="section_heading urbanist" data-aos="fade-up">Pongámonos en contacto.</h2>
                                                <p class="desc" data-aos="fade-up">Si tienes alguna duda, déjanos tu correo y nos pondremos en contacto contigo.</p>
                                            </div>
                                            <ul class="social">
                                                <li class="social_list" data-aos="fade-up">
                                                    <div class="social_content">
                                                        <div class="thumb">
                                                            <span><i class="fa-brands fa-instagram"></i></span>
                                                        </div>
                                                        <div class="content">
                                                            <h4><a href="https://www.instagram.com/numana.mx/">Instagram</a></h4>
                                                            <p>numana.mx</p>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="social_list" data-aos="fade-up">
                                                    <div class="social_content">
                                                        <div class="thumb">
                                                            <span><i class="fa-brands fa-facebook"></i></span>
                                                        </div>
                                                        <div class="content">
                                                            <h4><a href="https://www.facebook.com/profile.php?id=100081623947769">Facebook</a></h4>
                                                            <p>Numana</p>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="social_list" data-aos="fade-up">
                                                    <div class="social_content">
                                                        <div class="thumb">
                                                            <span><i class="fa-brands fa-whatsapp"></i></span>
                                                        </div>
                                                        <div class="content">
                                                            <h4><a href="https://wa.me/message/FMOIUCOCCMPNL1">Whatsapp</a></h4>
                                                            <p>+52 558 558 3103</p>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="contact_form">
                                            <form onsubmit="onSubmit(event)" id="form-contact">
                                                <?php echo csrf_field(); ?>
                                                <div class="cf_content">
                                                    <div class="cf_group">
                                                        <div class="cf_field" data-aos="fade-up">
                                                        <input 
                                                            type="text" 
                                                            name="name"
                                                            placeholder="Nombre"
                                                            required
                                                        />
                                                        </div>
                                                        <div class="cf_field" data-aos="fade-up">
                                                        <input 
                                                            type="email" 
                                                            name="email" 
                                                            placeholder="Email"
                                                            required
                                                        />
                                                        </div>
                                                    </div>
                                                    <div class="cf_group">
                                                        <div class="cf_field" data-aos="fade-up">
                                                        <input 
                                                            type="number" 
                                                            name="phone" 
                                                            placeholder="Telefono"
                                                            required
                                                        />
                                                        </div>
                                                        <div class="cf_field" data-aos="fade-up">
                                                        <input 
                                                            type="text" 
                                                            name="country" 
                                                            placeholder="Pais" 
                                                            required
                                                        />
                                                        </div>
                                                    </div>
                                                    <div class="cf_message">
                                                        <div class="cf_field" data-aos="fade-up">
                                                        <textarea 
                                                            name="message" 
                                                            id="message" 
                                                            placeholder="Mensaje" 
                                                            cols="30" 
                                                            rows="10"
                                                            required
                                                        ></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="cf_button" data-aos="fade-up">
                                                        <button type="submit" class="whiteButton2 buttonH1 text-center" id="submit">Enviar Mensaje</button>
                                                    </div>
                                                    <div class="d-none justify-content-center" id="loading">
                                                        <div class="spinner-border" role="status">
                                                            <span class="visually-hidden">Loading...</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="vector">
                            <img data-aos="slide-left" data-aos-delay="100" src="assets/images/vector/contactVector.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        
        const onSubmit = async (event) => {
            event.preventDefault()

            showLoading()

            try {

                const form = document.getElementById('form-contact')
                const data = new FormData(form)

                const res = await fetch('/send_email_contact', {
                    method: 'POST',
                    body: data
                })

                const values = await res.json()

                if (values.ok) {
                    showToast(values.message)
                    document.getElementById('form-contact').reset()
                } else {
                    showToast('Ocurrio un error, intentalo de nuevo', false)
                }

                hideLoading()

            } catch(e) {
                hideLoading()
                showToast('Ocurrio un error, intentalo de nuevo', false)
            }
        }

        const showLoading = () => {
            let btnSubmit = document.getElementById('submit')
            btnSubmit.classList.add('d-none')
            let loading = document.getElementById('loading')
            loading.classList.remove('d-none')
            loading.classList.add('d-flex')
        }

        const hideLoading = () => {
            let btnSubmit = document.getElementById('submit')
            btnSubmit.classList.remove('d-none')
            let loading = document.getElementById('loading')
            loading.classList.remove('d-flex')
            loading.classList.add('d-none')
        }

    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mercader_and_molina\resources\views/pages/contact.blade.php ENDPATH**/ ?>