

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Crear Blog</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('Blogs.index')); ?>">Blog</a></li>
                    <li class="breadcrumb-item active">Crear Blog</li>
                </ol>
            </div>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <h6>Por favor corrige los siguientes errores:</h6>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>  
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body text-center">
                    <form method="POST" action="<?php echo e(route("Users.store")); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-center">
                            <div class="col-md-6 text-left">
                                <div class="form-group">
                                    <label>Usuario</label>
                                    <input class="form-control" type="text" name="name" id="foto" placeholder="Escriba su nombre de usuario">
                                </div>
                            </div>
                            <div class="col-md-6 text-left">
                                <div class="form-group">
                                    <label>Correo Electronico</label>
                                    <input class="form-control" type="email" name="email" id="email" placeholder="Escriba su correo">
                                </div>
                            </div>

                            <div class="col-md-6 text-left">
                                <div class="form-group">
                                    <label>Rol de usuario</label>
                                    <select class="form-control" name="is_admin" id="is_admin">
                                        <option value="1">Administrador</option>
                                        <option value="0">Usuario</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 text-left">
                                <div class="form-group">
                                    <label>Contraseña</label>
                                    <input class="form-control" type="password" name="password" id="password" autocomplete="">
                                </div>
                            </div>

                        </div>
                        <div class="form-group mb-0">
                            <div>
                                <button type="submit" class="btn btn-client waves-effect waves-light mr-1">
                                    Crear
                                </button>
                                <a  class="btn btn-secondary waves-effect" href="<?php echo e(route('Users.index')); ?>">
                                    Cancel
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/assets/pages/form-advanced.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
 <!--Wysiwig js-->
 <script src="<?php echo e(asset('plugins/tinymce/tinymce.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mercader_and_molina\resources\views/pages/users/create.blade.php ENDPATH**/ ?>