<x-mail::message>
# Correo de contacto

Nombre: {{ $info->name }} <br>
Email: {{ $info->email }} <br>
Telefono: {{ $info->phone }} <br>
Empresa: {{ $info->company_name }} <br>
Mensaje: {{ $info->message }} <br>

</x-mail::message>
